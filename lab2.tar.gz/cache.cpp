#include <stddef.h>
#include "cache.h"

void mhLoad(void *addr, size_t size, void *instAddr){
  
}

void mhStore(void *addr, size_t size, void *instAddr){

}
