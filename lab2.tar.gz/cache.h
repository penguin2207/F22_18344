void mhLoad (void *, size_t, void *);
void mhStore(void *, size_t, void *);
